(() => {
	chrome.tabs.query({ active: true, currentWindow: true }, tab => {
		const efmrlContainer = document.getElementById("efmrl-container");
		const currentPage = tab[0].url;

		efmrlContainer.innerHTML = `<iframe id="efmrl-portal" src="https://efmrl.link/" height="440" width="280"></iframe>`;

		const efmrlPortalEl = document.getElementById("efmrl-portal");
		const efmrlPortal = efmrlPortalEl.contentWindow;

		efmrlPortalEl.addEventListener("load", () => {
			efmrlPortalEl.focus();
			efmrlPortal.postMessage(currentPage, "*");
		});
	});
})();
